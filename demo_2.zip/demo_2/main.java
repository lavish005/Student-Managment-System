import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        StudentManager manager = new StudentManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== Student Management System =====");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Add Marks");
            System.out.println("6. Mark Attendance");
            System.out.println("7. Search Student");
            System.out.println("8. Show Top Students");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");

            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1 -> manager.addStudent();
                case 2 -> manager.viewAllStudents();
                case 3 -> manager.updateStudent();
                case 4 -> manager.deleteStudent();
                case 5 -> manager.addMarks();
                case 6 -> manager.markAttendance();
                case 7 -> manager.searchStudent();
                case 8 -> manager.showTopStudents();
                case 9 -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }
}
