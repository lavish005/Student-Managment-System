import java.util.*;

public class Student {
    private String id;
    private String name;
    private int age;
    private Map<String, Integer> subjectMarks;
    private int attendance; // % attendance

    public Student(String id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.subjectMarks = new HashMap<>();
        this.attendance = 0;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public Map<String, Integer> getSubjectMarks() { return subjectMarks; }
    public int getAttendance() { return attendance; }

    public void setName(String name) { this.name = name; }
    public void setAge(int age) { this.age = age; }
    public void setAttendance(int attendance) { this.attendance = attendance; }

    public void addMark(String subject, int mark) {
        subjectMarks.put(subject, mark);
    }

    public double getAverageMarks() {
        if (subjectMarks.isEmpty()) return 0.0;
        return subjectMarks.values().stream().mapToInt(Integer::intValue).average().orElse(0.0);
    }

    public void display() {
        System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
        System.out.println("Marks:");
        subjectMarks.forEach((subject, mark) -> 
            System.out.println(" - " + subject + ": " + mark));
        System.out.println("Attendance: " + attendance + "%");
    }

    public String toFileString() {
        StringBuilder sb = new StringBuilder();
        sb.append(id).append(";").append(name).append(";").append(age).append(";").append(attendance);
        for (Map.Entry<String, Integer> entry : subjectMarks.entrySet()) {
            sb.append(";").append(entry.getKey()).append("=").append(entry.getValue());
        }
        return sb.toString();
    }

    public static Student fromFileString(String line) {
        try {
            String[] parts = line.split(";");
            String id = parts[0];
            String name = parts[1];
            int age = Integer.parseInt(parts[2]);
            int attendance = Integer.parseInt(parts[3]);

            Student s = new Student(id, name, age);
            s.setAttendance(attendance);
            for (int i = 4; i < parts.length; i++) {
                String[] markParts = parts[i].split("=");
                if (markParts.length == 2) {
                    s.addMark(markParts[0], Integer.parseInt(markParts[1]));
                }
            }
            return s;
        } catch (Exception e) {
            return null;
        }
    }
}
