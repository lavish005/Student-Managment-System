import java.io.PrintWriter;
import java.util.*;

public class StudentManager {
    private static final String FILE_NAME = "students.txt";
    private List<Student> students = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    // ✅ Constructor to load data and register shutdown hook
    public StudentManager() {
        loadFromFile();
        Runtime.getRuntime().addShutdownHook(new Thread(this::saveToFile));
    }

    public void addStudent() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        if (findStudentById(id) != null) {
            System.out.println("Student with this ID already exists!");
            return;
        }

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Age: ");
        int age = Integer.parseInt(scanner.nextLine());
        students.add(new Student(id, name, age));
        System.out.println("Student added successfully.");
    }

    public void viewAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
            return;
        }
        for (Student s : students) {
            s.display();
            System.out.println("------");
        }
    }

    public void updateStudent() {
        System.out.print("Enter Student ID to update: ");
        String id = scanner.nextLine();
        Student s = findStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter new name: ");
        s.setName(scanner.nextLine());
        System.out.print("Enter new age: ");
        s.setAge(Integer.parseInt(scanner.nextLine()));
        System.out.println("Student updated.");
    }

    public void deleteStudent() {
        System.out.print("Enter Student ID to delete: ");
        String id = scanner.nextLine();
        Student s = findStudentById(id);
        if (s != null) {
            students.remove(s);
            System.out.println("Student deleted.");
        } else {
            System.out.println("Student not found.");
        }
    }

    public void addMarks() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        Student s = findStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter subject name: ");
        String subject = scanner.nextLine();
        System.out.print("Enter marks: ");
        int marks = Integer.parseInt(scanner.nextLine());
        s.addMark(subject, marks);
        System.out.println("Marks added.");
    }

    public void markAttendance() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        Student s = findStudentById(id);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter attendance percentage: ");
        int percent = Integer.parseInt(scanner.nextLine());
        s.setAttendance(percent);
        System.out.println("Attendance updated.");
    }

    public void searchStudent() {
        System.out.print("Search by ID or Name? ");
        String choice = scanner.nextLine().toLowerCase();
        if (choice.equals("id")) {
            System.out.print("Enter ID: ");
            String id = scanner.nextLine();
            Student s = findStudentById(id);
            if (s != null) s.display();
            else System.out.println("Student not found.");
        } else {
            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            for (Student s : students) {
                if (s.getName().equalsIgnoreCase(name)) {
                    s.display();
                    return;
                }
            }
            System.out.println("Student not found.");
        }
    }

    public void showTopStudents() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
            return;
        }

        System.out.print("Enter number of top students: ");
        int k = Integer.parseInt(scanner.nextLine());

        students.stream()
            .sorted((a, b) -> Double.compare(b.getAverageMarks(), a.getAverageMarks()))
            .limit(k)
            .forEach(s -> {
                s.display();
                System.out.printf("Average Marks: %.2f%n", s.getAverageMarks());
                System.out.println("------");
            });
    }

    private Student findStudentById(String id) {
        for (Student s : students)
            if (s.getId().equalsIgnoreCase(id)) return s;
        return null;
    }

    private void saveToFile() {
        try (PrintWriter pw = new PrintWriter(FILE_NAME)) {
            for (Student s : students) {
                pw.println(s.toFileString());
            }
        } catch (Exception e) {
            System.out.println("Error saving student data.");
        }
    }

    private void loadFromFile() {
        try (Scanner fileScanner = new Scanner(new java.io.File(FILE_NAME))) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                Student s = Student.fromFileString(line);
                if (s != null) students.add(s);
            }
            System.out.println("Student data loaded from file.");
        } catch (Exception e) {
            System.out.println("No existing data file found.");
        }
    }
}
